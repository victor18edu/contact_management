
<?php $__env->startSection('css'); ?>
<style>
    .my-custom-pagination {
        background-color: #f2f2f2;
        padding: 10px;
    }

    .my-custom-pagination a {
        color: #333;
        text-decoration: none;
        padding: 5px;
        margin: 5px;
    }

    .my-custom-pagination .active a {
        background-color: #007bff;
        color: #fff;
    }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <h2><?php echo e(__('Contact list')); ?></h1>
        <div class="text-end">
            <a href="<?php echo e(route('contacts.create')); ?>" class="btn btn-success"><?php echo e(__('Add Contact')); ?></a>
        </div>
        <div class="mb-3">
          <form action="<?php echo e(route('contacts.index')); ?>">
                <label for="recordsPerPage"><?php echo e(__('Records per page')); ?>:</label>
                <select name="recordsPerPage" id="recordsPerPage" onchange="this.form.submit()">
                    <option value="5" <?php echo e($recordsPerPage == 5 ? 'selected' : ''); ?>>5</option>
                    <option value="10" <?php echo e($recordsPerPage == 10 ? 'selected' : ''); ?>>10</option>
                    <option value="20" <?php echo e($recordsPerPage == 20 ? 'selected' : ''); ?>>20</option>
                </select>
          </form>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th><?php echo e(__('ID')); ?></th>
                    <th><?php echo e(__('Name')); ?></th>
                    <th><?php echo e(__('Contact')); ?></th>
                    <th><?php echo e(__('Email')); ?></th>
                    <?php if(Auth::check()): ?>
                        <th><?php echo e(__('Actions')); ?></th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($contact->id); ?></td>
                        <td><?php echo e($contact->name); ?></td>
                        <td><?php echo e($contact->contact); ?></td>
                        <td><?php echo e($contact->email); ?></td>
                        <?php if(Auth::check()): ?>
                            <td>
                                <a href="<?php echo e(route('contacts.show', $contact)); ?>"
                                    class="btn btn-primary btn-sm"><?php echo e(__('Details')); ?></a>
                                <a href="<?php echo e(route('contacts.edit', $contact)); ?>"
                                    class="btn btn-warning btn-sm"><?php echo e(__('Edit')); ?></a>
                                <form action="<?php echo e(route('contacts.destroy', $contact)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure you want to delete this contact?')"><?php echo e(__('Delete')); ?></button>
                                </form>
                            </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5"><?php echo e(__('No contacts found.')); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
            
            <tfoot>
                <tr>
                    <th><?php echo e(__('ID')); ?></th>
                    <th><?php echo e(__('Name')); ?></th>
                    <th><?php echo e(__('Contact')); ?></th>
                    <th><?php echo e(__('Email')); ?></th>
                    <?php if(Auth::check()): ?>
                        <th><?php echo e(__('Actions')); ?></th>
                    <?php endif; ?>
                </tr>
            </tfoot>
        </table>
        <div class="pagination justify-content-center">
            <?php echo e($contacts->links()); ?>

        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danie\OneDrive\Documentos\Projetos\Victor\me\contact_management\resources\views/contacts/index.blade.php ENDPATH**/ ?>